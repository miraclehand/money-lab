CONNECTION_ALIAS = 'stockdb'

